<?php
/**
 * Title: Dreamy Bear (productpagina)
 * Slug: beer/product-dreamy-bear
 * Categories: beer
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><a href="<?php echo beer_link( 'shop' ); ?>">Shop</a> › Dreamy Bear</p>
<!-- /wp:paragraph --><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"beer-galerij-groot","layout":{"type":"constrained"}} -->
<div class="wp-block-group beer-galerij-groot"><!-- wp:image {"width":"70%","sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><img src="<?php echo beer_img( 'ill/dreamy.webp' ); ?>" alt="Dreamy Bear" style="width:70%"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Dreamy Bear</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"beer-product-prijs"} -->
<p class="beer-product-prijs">€ 24,95</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Dreamy Bear is licht als een wolkje. Met een geurtje lavendel erbij is hij de perfecte slaapvriend.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"beer-koop"} -->
<div class="wp-block-button beer-koop"><a class="wp-block-button__link wp-element-button" href="mailto:info@beer.be?subject=Bestelling%20Dreamy%20Bear">Bestel Dreamy Bear →</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --><!-- wp:paragraph -->
<p><a href="<?php echo beer_link( 'samenstellen' ); ?>"><strong>Of maak hem helemaal van jou: geurtje, kloppend hartje en paspoort →</strong></a></p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"grid","columnCount":2,"minimumColumnWidth":"12rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"beer-ico-rij","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group beer-ico-rij"><!-- wp:image {"width":"26px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo beer_img( 'icons/uniek.svg' ); ?>" alt="" style="width:26px"/></figure>
<!-- /wp:image --><!-- wp:paragraph -->
<p>Levering in 2–3 werkdagen</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"beer-ico-rij","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group beer-ico-rij"><!-- wp:image {"width":"26px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo beer_img( 'icons/hart.svg' ); ?>" alt="" style="width:26px"/></figure>
<!-- /wp:image --><!-- wp:paragraph -->
<p>Gratis verzending vanaf € 40</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"beer-ico-rij","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group beer-ico-rij"><!-- wp:image {"width":"26px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo beer_img( 'icons/met-liefde.svg' ); ?>" alt="" style="width:26px"/></figure>
<!-- /wp:image --><!-- wp:paragraph -->
<p>14 dagen bedenktijd</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"beer-ico-rij","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group beer-ico-rij"><!-- wp:image {"width":"26px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo beer_img( 'icons/veilig.svg' ); ?>" alt="" style="width:26px"/></figure>
<!-- /wp:image --><!-- wp:paragraph -->
<p>Veilig betalen met Bancontact</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --><!-- wp:group {"className":"beer-specs","layout":{"type":"constrained"}} -->
<div class="wp-block-group beer-specs"><!-- wp:group {"className":"beer-spec","layout":{"type":"grid","columnCount":2}} -->
<div class="wp-block-group beer-spec"><!-- wp:paragraph -->
<p><strong>Hoogte</strong></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>30 cm</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"beer-spec","layout":{"type":"grid","columnCount":2}} -->
<div class="wp-block-group beer-spec"><!-- wp:paragraph -->
<p><strong>Materiaal</strong></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Zacht pluche, gerecycleerde vulling</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"beer-spec","layout":{"type":"grid","columnCount":2}} -->
<div class="wp-block-group beer-spec"><!-- wp:paragraph -->
<p><strong>Leeftijd</strong></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Vanaf 0 jaar</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"beer-spec","layout":{"type":"grid","columnCount":2}} -->
<div class="wp-block-group beer-spec"><!-- wp:paragraph -->
<p><strong>Wassen</strong></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Handwas of 30°C in een kussensloop</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Ook leuk</h2>
<!-- /wp:heading --><!-- wp:group {"layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"9rem"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"is-style-kaart","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-kaart"><!-- wp:image {"width":"120px","sizeSlug":"full","linkDestination":"custom","align":"center"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><a href="<?php echo beer_link( 'shop/classic-bear' ); ?>"><img src="<?php echo beer_img( 'ill/classic.webp' ); ?>" alt="Classic Bear" style="width:120px"/></a></figure>
<!-- /wp:image --><!-- wp:heading {"textAlign":"center","level":3} -->
<h3 class="wp-block-heading has-text-align-center"><a href="<?php echo beer_link( 'shop/classic-bear' ); ?>">Classic Bear</a></h3>
<!-- /wp:heading --><!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">€ 24,95</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"is-style-kaart","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-kaart"><!-- wp:image {"width":"120px","sizeSlug":"full","linkDestination":"custom","align":"center"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><a href="<?php echo beer_link( 'shop/brownie-bear' ); ?>"><img src="<?php echo beer_img( 'ill/brownie.webp' ); ?>" alt="Brownie Bear" style="width:120px"/></a></figure>
<!-- /wp:image --><!-- wp:heading {"textAlign":"center","level":3} -->
<h3 class="wp-block-heading has-text-align-center"><a href="<?php echo beer_link( 'shop/brownie-bear' ); ?>">Brownie Bear</a></h3>
<!-- /wp:heading --><!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">€ 24,95</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:group {"className":"is-style-kaart","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-kaart"><!-- wp:image {"width":"120px","sizeSlug":"full","linkDestination":"custom","align":"center"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><a href="<?php echo beer_link( 'shop/little-bear' ); ?>"><img src="<?php echo beer_img( 'ill/little.webp' ); ?>" alt="Little Bear" style="width:120px"/></a></figure>
<!-- /wp:image --><!-- wp:heading {"textAlign":"center","level":3} -->
<h3 class="wp-block-heading has-text-align-center"><a href="<?php echo beer_link( 'shop/little-bear' ); ?>">Little Bear</a></h3>
<!-- /wp:heading --><!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">€ 22,95</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
