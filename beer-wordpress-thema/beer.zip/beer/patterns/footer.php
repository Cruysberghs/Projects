<?php
/**
 * Title: Footer
 * Slug: beer/footer
 * Categories: beer
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"perzik","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-perzik-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"width":"44px","sizeSlug":"full","linkDestination":"custom"} -->
<figure class="wp-block-image size-full is-resized"><a href="<?php echo beer_link( '' ); ?>"><img src="<?php echo beer_img( 'bear-classic.svg' ); ?>" alt="" style="width:44px"/></a></figure>
<!-- /wp:image --><!-- wp:site-title {"level":0} /--></div>
<!-- /wp:group --><!-- wp:paragraph -->
<p>Jouw knuffel, jouw verhaal.</p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"beer-hand","fontSize":"x-large"} -->
<p class="beer-hand has-x-large-font-size">Een knuffel voor het leven ♡</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Ontdek</h3>
<!-- /wp:heading --><!-- wp:list {"className":"beer-footer-links"} -->
<ul class="wp-block-list beer-footer-links"><!-- wp:list-item -->
<li><a href="<?php echo beer_link( 'shop' ); ?>">Shop</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo beer_link( 'samenstellen' ); ?>">Stel jouw BEER. samen</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo beer_link( 'workshops' ); ?>">Workshops</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo beer_link( 'kinderfeestjes' ); ?>">Kinderfeestjes</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo beer_link( 'kampjes' ); ?>">Kampjes</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo beer_link( 'faq' ); ?>">FAQ</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Contact</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>✉ <a href="mailto:info@beer.be">info@beer.be</a><br>☎ <a href="tel:+32479123456">+32 479 12 34 56</a><br>📍 Straatnaam 12, 9000 Gent</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --><!-- wp:paragraph {"align":"center","fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size">© <?php echo esc_html( gmdate( 'Y' ) ); ?> BEER. – Met liefde gemaakt</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
